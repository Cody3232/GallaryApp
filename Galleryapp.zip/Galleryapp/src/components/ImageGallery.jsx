import React from 'react';

const ImageGallery = ({ images }) => {
  return (
    <div>
      <h2>Gallery</h2>
      <div className="gallery">
        {images.map((image, index) => (
          <img key={index} src={image} alt="Gallery item" />
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;
