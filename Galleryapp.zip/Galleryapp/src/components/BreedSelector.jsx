import React from 'react';

const BreedSelector = ({ breeds, onBreedChange }) => {
  return (
    <div>
      <h2>Select a Breed</h2>
      <select onChange={(e) => onBreedChange(e.target.value)}>
        {breeds.map((breed, index) => (
          <option key={index} value={breed}>
            {breed}
          </option>
        ))}
      </select>
    </div>
  );
};

export default BreedSelector;
