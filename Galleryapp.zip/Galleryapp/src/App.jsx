
import { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [images, setImages] = useState([]);
  const [breed, setBreed] = useState('bulldog'); 
  const [breeds, setBreeds] = useState([]);

  // Fetch images for the selected breed
  useEffect(() => {
    // Fetch random dog images for a specific breed
    axios
      .get(`https://dog.ceo/api/breed/${breed}/images/random/3`)
      .then((response) => {
        setImages(response.data.message);
      })
      .catch((error) => {
        console.error('Error fetching images:', error);
      });
  }, [breed]);

  // Using fetch to obtain the breed names
  useEffect(() => {
    axios
      .get('https://dog.ceo/api/breeds/list/all')
      .then((response) => {
        setBreeds(Object.keys(response.data.message)); // How i recieve the breed names
      })
      .catch((error) => {
        console.error('Error fetching breeds:', error);
      });
  }, []);

  return (
    <div className="App">
      <h1>Welcome to the Dog Breed Gallery App!</h1>
      
      {/* Breed Selector */}
      <div>
        <label htmlFor="breedSelector">Select a Breed</label>
        <select
          id="breedSelector"
          onChange={(e) => setBreed(e.target.value)}
          value={breed}
        >
          {breeds.map((breed, index) => (
            <option key={index} value={breed}>
              {breed}
            </option>
          ))}
        </select>
      </div>

      {/* Gallery */}
      <div>
        <h2>Enjoy!</h2>
        <div className="gallery">
          {images.length === 0 ? (
            <p>Loading images...</p>
          ) : (
            images.map((image, index) => (
              <img key={index} src={image} alt="Dog" />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
